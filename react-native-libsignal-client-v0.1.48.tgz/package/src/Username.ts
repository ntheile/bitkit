import ReactNativeLibsignalClientModule from './ReactNativeLibsignalClientModule';

/**
 * Result of parsing or creating a username with its hash
 */
export interface UsernameWithHash {
	username: string;
	hash: Uint8Array;
}

/**
 * Username link data containing entropy and encrypted username
 */
export interface UsernameLink {
	entropy: Uint8Array;
	encryptedUsername: Uint8Array;
}

/**
 * Default minimum length for nickname portion of username
 */
export const MIN_NICKNAME_LENGTH = 3;

/**
 * Default maximum length for nickname portion of username
 */
export const MAX_NICKNAME_LENGTH = 32;

/**
 * Compute the hash of a username.
 *
 * The username must be in the format "nickname.discriminator" where:
 * - nickname is 3-32 characters (letters, numbers, underscores)
 * - discriminator is 2-9 digits (01-999999999, no leading zeros except for 01-09)
 *
 * @param username - The username to hash (e.g., "alice.42")
 * @returns 32-byte hash of the username
 * @throws If the username format is invalid
 */
export function hash(username: string): Uint8Array {
	return new Uint8Array(
		ReactNativeLibsignalClientModule.usernameHash(username)
	);
}

/**
 * Generate a zero-knowledge proof that you know the username for a given hash.
 *
 * @param username - The username to generate a proof for
 * @returns 128-byte proof that can be verified with verifyProof()
 * @throws If the username format is invalid
 */
export function generateProof(username: string): Uint8Array {
	const randomness = new Uint8Array(32);
	crypto.getRandomValues(randomness);
	return new Uint8Array(
		ReactNativeLibsignalClientModule.usernameProof(username, randomness)
	);
}

/**
 * Generate a zero-knowledge proof with specified randomness.
 *
 * This is useful for deterministic testing. In production, use generateProof() instead.
 *
 * @param username - The username to generate a proof for
 * @param randomness - 32 bytes of randomness
 * @returns 128-byte proof that can be verified with verifyProof()
 * @throws If the username format is invalid or randomness is wrong length
 */
export function generateProofWithRandomness(
	username: string,
	randomness: Uint8Array
): Uint8Array {
	if (randomness.length !== 32) {
		throw new Error('randomness must be 32 bytes');
	}
	return new Uint8Array(
		ReactNativeLibsignalClientModule.usernameProof(username, randomness)
	);
}

/**
 * Verify a zero-knowledge proof that someone knows the username for a given hash.
 *
 * @param proof - 128-byte proof from generateProof()
 * @param hash - 32-byte hash from hash()
 * @throws If the proof is invalid or does not match the hash
 */
export function verifyProof(proof: Uint8Array, hash: Uint8Array): void {
	ReactNativeLibsignalClientModule.usernameVerify(proof, hash);
}

/**
 * Generate candidate usernames from a nickname.
 *
 * This generates multiple username candidates with random discriminators
 * that the user can choose from or that can be checked for availability.
 *
 * @param nickname - The nickname portion (e.g., "alice")
 * @param minNicknameLength - Minimum nickname length (default: 3)
 * @param maxNicknameLength - Maximum nickname length (default: 32)
 * @returns Array of candidate usernames (e.g., ["alice.42", "alice.123", ...])
 * @throws If the nickname is invalid
 */
export function candidatesFrom(
	nickname: string,
	minNicknameLength: number = MIN_NICKNAME_LENGTH,
	maxNicknameLength: number = MAX_NICKNAME_LENGTH
): string[] {
	return ReactNativeLibsignalClientModule.usernameCandidatesFrom(
		nickname,
		minNicknameLength,
		maxNicknameLength
	);
}

/**
 * Create a username from separate nickname and discriminator parts.
 *
 * @param nickname - The nickname portion (e.g., "alice")
 * @param discriminator - The discriminator portion (e.g., "42")
 * @param minNicknameLength - Minimum nickname length (default: 3)
 * @param maxNicknameLength - Maximum nickname length (default: 32)
 * @returns Username string and its hash
 * @throws If the nickname or discriminator is invalid
 */
export function fromParts(
	nickname: string,
	discriminator: string,
	minNicknameLength: number = MIN_NICKNAME_LENGTH,
	maxNicknameLength: number = MAX_NICKNAME_LENGTH
): UsernameWithHash {
	const result = ReactNativeLibsignalClientModule.usernameFromParts(
		nickname,
		discriminator,
		minNicknameLength,
		maxNicknameLength
	);
	return {
		username: result.username,
		hash: new Uint8Array(result.hash),
	};
}

/**
 * Create an encrypted username link.
 *
 * Username links allow sharing usernames via QR codes or URLs without
 * revealing the username to the server. The link contains:
 * - entropy: 32 bytes used to derive encryption keys (included in the link)
 * - encryptedUsername: The encrypted username (stored on the server)
 *
 * @param username - The username to create a link for
 * @param previousEntropy - Optional entropy to reuse (for link rotation)
 * @returns UsernameLink with entropy and encryptedUsername
 * @throws If the username format is invalid
 */
export function createLink(
	username: string,
	previousEntropy?: Uint8Array
): UsernameLink {
	const result = new Uint8Array(
		ReactNativeLibsignalClientModule.usernameLinkCreate(
			username,
			previousEntropy ?? null
		)
	);
	// First 32 bytes are entropy, rest is encryptedUsername
	return {
		entropy: result.slice(0, 32),
		encryptedUsername: result.slice(32),
	};
}

/**
 * Decrypt a username from a username link.
 *
 * @param entropy - 32 bytes of entropy from the link
 * @param encryptedUsername - The encrypted username from the server
 * @returns The decrypted username
 * @throws If decryption fails (invalid entropy or corrupted data)
 */
export function decryptLink(
	entropy: Uint8Array,
	encryptedUsername: Uint8Array
): string {
	return ReactNativeLibsignalClientModule.usernameLinkDecrypt(
		entropy,
		encryptedUsername
	);
}

/**
 * Decrypt a username from a UsernameLink object.
 *
 * @param link - UsernameLink containing entropy and encryptedUsername
 * @returns The decrypted username
 * @throws If decryption fails
 */
export function decryptLinkData(link: UsernameLink): string {
	return decryptLink(link.entropy, link.encryptedUsername);
}
