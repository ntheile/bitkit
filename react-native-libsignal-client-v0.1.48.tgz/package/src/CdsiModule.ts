import { requireNativeModule } from 'expo-modules-core';

const module = requireNativeModule('Cdsi');

export default module;
