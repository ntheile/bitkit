import CdsiModule from './CdsiModule';

/**
 * A service ID (ACI) paired with its profile key.
 * Used for looking up contacts that you already have a relationship with.
 * The profile key is used to derive the access key for the lookup.
 */
export interface ServiceIdAndProfileKey {
	/** The ACI (Account Identity) as a UUID string */
	aci: string;
	/** The 32-byte profile key as base64 string */
	profileKey: string;
}

/**
 * A single entry in the CDSI lookup response.
 */
export interface CdsiLookupResponseEntry {
	/** The E.164 phone number that was looked up */
	e164: string;
	/** The ACI (Account Identity) if the user is registered, null otherwise */
	aci: string | null;
	/** The PNI (Phone Number Identity) if available, null otherwise */
	pni: string | null;
}

/**
 * Response from a CDSI lookup.
 */
export interface CdsiLookupResponse {
	/** Map of E.164 to lookup result */
	entries: CdsiLookupResponseEntry[];
	/** Token to use for subsequent incremental lookups (base64 encoded) */
	token: string;
	/** Debug info: number of rate limit permits used */
	debugPermitsUsed: number;
}

/**
 * Signal environment for CDSI lookups.
 */
export enum CdsiEnvironment {
	/** Signal's staging environment */
	Staging = 'staging',
	/** Signal's production environment */
	Production = 'production',
}

/**
 * Options for CDSI lookup - all parameters in a single object.
 */
export interface CdsiLookupOptions {
	/** Username for CDSI authentication (from /v2/directory/auth) */
	username: string;
	/** Password for CDSI authentication (from /v2/directory/auth) */
	password: string;
	/** Signal environment (Production or Staging) */
	environment: CdsiEnvironment;
	/** E.164 phone numbers to look up (e.g., "+14155551234") */
	phoneNumbers: string[];
	/** App name / user agent string for the request */
	appName: string;
	/** Previously looked up E.164 numbers (for incremental lookups) */
	prevPhoneNumbers?: string[];
	/** Service IDs with profile keys for existing contacts */
	serviceIdsAndProfileKeys?: ServiceIdAndProfileKey[];
	/** Token from a previous lookup (for incremental lookups) */
	token?: string;
}

/**
 * Perform a CDSI (Contact Discovery Service) lookup.
 *
 * CDSI allows privacy-preserving contact discovery by using Intel SGX secure enclaves.
 * The server cannot see the plaintext phone numbers being looked up.
 *
 * @param options - All lookup options in a single object
 * @returns Promise resolving to the lookup response with ACIs/PNIs for registered users
 *
 * @example
 * ```typescript
 * import { cdsiLookup, CdsiEnvironment } from 'react-native-libsignal-client';
 *
 * const response = await cdsiLookup({
 *   username: 'username-from-directory-auth',
 *   password: 'password-from-directory-auth',
 *   environment: CdsiEnvironment.Production,
 *   phoneNumbers: ['+14155551234', '+14155555678'],
 *   appName: 'MyApp/1.0'
 * });
 *
 * for (const entry of response.entries) {
 *   if (entry.aci) {
 *     console.log(`${entry.e164} is registered with ACI: ${entry.aci}`);
 *   }
 * }
 * ```
 */
export async function cdsiLookup(
	options: CdsiLookupOptions
): Promise<CdsiLookupResponse> {
	const {
		username,
		password,
		environment,
		phoneNumbers,
		appName,
		prevPhoneNumbers,
		serviceIdsAndProfileKeys,
		token,
	} = options;

	// Prepare the request object for native bridge
	const nativeRequest = {
		e164s: phoneNumbers,
		prevE164s: prevPhoneNumbers ?? [],
		serviceIdsAndProfileKeys: serviceIdsAndProfileKeys ?? [],
		token: token ?? null,
	};

	const response = await CdsiModule.cdsiLookup(
		username,
		password,
		nativeRequest,
		environment,
		appName
	);

	return {
		entries: response.entries,
		token: response.token,
		debugPermitsUsed: response.debugPermitsUsed,
	};
}

/**
 * Check if CDSI functionality is available on this platform.
 *
 * @returns true if CDSI is available, false otherwise
 */
export function isCdsiAvailable(): boolean {
	return CdsiModule != null && typeof CdsiModule.cdsiLookup === 'function';
}
