import ExpoModulesCore
import LibSignalClient

/// Native module for CDSI (Contact Discovery Service) lookups.
///
/// This module provides privacy-preserving phone number to ACI/PNI lookup
/// through Signal's Contact Discovery Service using Intel SGX enclaves.
public class CdsiModule: Module {
    public func definition() -> ModuleDefinition {
        Name("Cdsi")

        AsyncFunction("cdsiLookup") { (
            username: String,
            password: String,
            request: [String: Any],
            environment: String,
            userAgent: String,
            promise: Promise
        ) in
            Task {
                do {
                    let result = try await self.performCdsiLookup(
                        username: username,
                        password: password,
                        request: request,
                        environment: environment,
                        userAgent: userAgent
                    )
                    promise.resolve(result)
                } catch {
                    promise.reject("CDSI_ERROR", error.localizedDescription)
                }
            }
        }
    }
    
    private func performCdsiLookup(
        username: String,
        password: String,
        request: [String: Any],
        environment: String,
        userAgent: String
    ) async throws -> [String: Any] {
        // Determine environment
        let networkEnv: Net.Environment = environment.lowercased() == "staging" ? .staging : .production
        
        // Create network instance
        let network = Net(env: networkEnv, userAgent: userAgent)
        
        // Parse request parameters
        let e164s = (request["e164s"] as? [String]) ?? []
        let prevE164s = (request["prevE164s"] as? [String]) ?? []
        let tokenString = request["token"] as? String
        let serviceIdsAndProfileKeys = (request["serviceIdsAndProfileKeys"] as? [[String: String]]) ?? []
        
        // Build the CDSI lookup request
        var cdsiRequest = CdsiLookupRequest()
        
        // Add new phone numbers to look up
        for e164 in e164s {
            cdsiRequest.addE164(e164)
        }
        
        // Add previously looked up numbers (for incremental lookups)
        for e164 in prevE164s {
            cdsiRequest.addPreviousE164(e164)
        }
        
        // Add token if provided (for incremental lookups)
        if let tokenString = tokenString, !tokenString.isEmpty,
           let tokenData = Data(base64Encoded: tokenString) {
            cdsiRequest.token = tokenData
        }
        
        // Add service IDs with profile keys for existing contacts
        for entry in serviceIdsAndProfileKeys {
            if let aciString = entry["aci"],
               let profileKeyString = entry["profileKey"],
               let aci = try? Aci.parseFrom(serviceIdString: aciString),
               let profileKeyData = Data(base64Encoded: profileKeyString) {
                cdsiRequest.addAciAndAccessKey(aci: aci, profileKeyData: profileKeyData)
            }
        }
        
        // Perform the lookup
        let auth = Net.Auth(username: username, password: password)
        let cdsiLookup = try network.cdsiLookup(auth: auth, request: cdsiRequest, timeout: 10.0)
        let response = try await cdsiLookup.complete()
        
        // Convert response to dictionary format
        var entries: [[String: Any?]] = []
        for (e164, lookupEntry) in response.entries {
            var entryDict: [String: Any?] = [:]
            entryDict["e164"] = e164
            entryDict["aci"] = lookupEntry.aci?.serviceIdString
            entryDict["pni"] = lookupEntry.pni?.serviceIdString
            entries.append(entryDict)
        }
        
        // Return result
        var result: [String: Any] = [:]
        result["entries"] = entries
        result["token"] = response.token.base64EncodedString()
        result["debugPermitsUsed"] = response.debugPermitsUsed
        
        return result
    }
}
