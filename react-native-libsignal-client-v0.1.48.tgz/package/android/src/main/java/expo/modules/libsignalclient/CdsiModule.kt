package expo.modules.libsignalclient

import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import expo.modules.kotlin.Promise
import org.signal.libsignal.net.Network
import org.signal.libsignal.net.CdsiLookupRequest
import org.signal.libsignal.net.CdsiLookupResponse
import org.signal.libsignal.protocol.ServiceId.Aci
import org.signal.libsignal.zkgroup.profiles.ProfileKey
import java.util.Optional
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Native module for CDSI (Contact Discovery Service) lookups.
 * 
 * This module provides privacy-preserving phone number to ACI/PNI lookup
 * through Signal's Contact Discovery Service using Intel SGX enclaves.
 */
class CdsiModule : Module() {
    private val executor: ExecutorService = Executors.newCachedThreadPool()
    
    override fun definition() = ModuleDefinition {
        Name("Cdsi")

        AsyncFunction("cdsiLookup") { 
            username: String,
            password: String,
            request: Map<String, Any?>,
            environment: String,
            userAgent: String,
            promise: Promise ->
            
            executor.execute {
                try {
                    val result = performCdsiLookup(username, password, request, environment, userAgent)
                    promise.resolve(result)
                } catch (e: Exception) {
                    promise.reject("CDSI_ERROR", e.message ?: "CDSI lookup failed", e)
                }
            }
        }
    }
    
    private fun performCdsiLookup(
        username: String,
        password: String,
        request: Map<String, Any?>,
        environment: String,
        userAgent: String
    ): Map<String, Any> {
        // Determine environment
        val networkEnv = when (environment.lowercase()) {
            "staging" -> Network.Environment.STAGING
            else -> Network.Environment.PRODUCTION
        }
        
        // Create network instance
        val network = Network(networkEnv, userAgent)
        
        // Parse request parameters
        @Suppress("UNCHECKED_CAST")
        val e164s = (request["e164s"] as? List<String>) ?: emptyList()
        @Suppress("UNCHECKED_CAST")
        val prevE164s = (request["prevE164s"] as? List<String>) ?: emptyList()
        val tokenString = request["token"] as? String
        @Suppress("UNCHECKED_CAST")
        val serviceIdsAndProfileKeys = request["serviceIdsAndProfileKeys"] as? List<Map<String, String>> ?: emptyList()
        
        // Build sets for the request
        val newE164Set = e164s.toMutableSet()
        val prevE164Set = prevE164s.toMutableSet()
        
        // Build service IDs map
        val serviceIdsMap = mutableMapOf<org.signal.libsignal.protocol.ServiceId, ProfileKey>()
        for (entry in serviceIdsAndProfileKeys) {
            val aciString = entry["aci"]
            val profileKeyString = entry["profileKey"]
            if (aciString != null && profileKeyString != null) {
                try {
                    val aci = Aci.parseFromString(aciString)
                    val profileKeyBytes = android.util.Base64.decode(profileKeyString, android.util.Base64.DEFAULT)
                    val profileKey = ProfileKey(profileKeyBytes)
                    serviceIdsMap[aci] = profileKey
                } catch (e: Exception) {
                    // Skip invalid entries
                }
            }
        }
        
        // Parse token
        val tokenOptional: Optional<ByteArray> = if (tokenString != null && tokenString.isNotEmpty()) {
            Optional.of(android.util.Base64.decode(tokenString, android.util.Base64.DEFAULT))
        } else {
            Optional.empty()
        }
        
        // Build the CDSI lookup request
        val cdsiRequest = CdsiLookupRequest(
            prevE164Set,
            newE164Set,
            serviceIdsMap,
            tokenOptional
        )
        
        // Store token for response
        var responseToken: ByteArray? = null
        val tokenConsumer: java.util.function.Consumer<ByteArray> = java.util.function.Consumer { token ->
            responseToken = token
        }
        
        // Perform the lookup
        val responseFuture = network.cdsiLookup(username, password, cdsiRequest, tokenConsumer)
        val response = responseFuture.get()
        
        // Convert response to map format
        val entries = mutableListOf<Map<String, Any?>>()
        for ((e164, lookupEntry) in response.entries()) {
            val entryMap = mutableMapOf<String, Any?>()
            entryMap["e164"] = e164
            entryMap["aci"] = lookupEntry.aci?.toServiceIdString()
            entryMap["pni"] = lookupEntry.pni?.toServiceIdString()
            entries.add(entryMap)
        }
        
        // Return result
        val result = mutableMapOf<String, Any>()
        result["entries"] = entries
        result["token"] = if (responseToken != null) {
            android.util.Base64.encodeToString(responseToken, android.util.Base64.NO_WRAP)
        } else {
            ""
        }
        result["debugPermitsUsed"] = response.debugPermitsUsed
        
        return result
    }
}
