package expo.modules.libsignalclient;

// Stubbed out - ValidatingMac uses internal Native API not available in libsignal 0.78+
public class ValidatingMac {
    public ValidatingMac(byte[] key, int chunkSize, byte[] digest) {
        throw new UnsupportedOperationException("ValidatingMac not available in libsignal 0.81+");
    }

    static public int calculateChunkSize(int dataSize) {
        throw new UnsupportedOperationException("ValidatingMac not available in libsignal 0.81+");
    }

    public int update(byte[] chunk) {
        throw new UnsupportedOperationException("ValidatingMac not available in libsignal 0.81+");
    }

    public int _finalize() {
        throw new UnsupportedOperationException("ValidatingMac not available in libsignal 0.81+");
    }
}
