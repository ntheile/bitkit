package expo.modules.libsignalclient

// Stubbed out - IncrementalMac uses internal Native API not available in libsignal 0.78+
// Use IncrementalMacInputStream/IncrementalMacOutputStream from org.signal.libsignal.protocol.incrementalmac if needed
class IncrementalMac(key: ByteArray, chunkSize: Int) {
    fun update(data: ByteArray): ByteArray {
        throw UnsupportedOperationException("IncrementalMac not available in libsignal 0.81+")
    }

    fun finalize(): ByteArray {
        throw UnsupportedOperationException("IncrementalMac not available in libsignal 0.81+")
    }
}
